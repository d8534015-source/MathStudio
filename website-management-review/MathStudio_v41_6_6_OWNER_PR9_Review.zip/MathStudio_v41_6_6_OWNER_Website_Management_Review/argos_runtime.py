"""Lightweight OWNER adapter. Never imports Argos into the HTTP/teacher process."""
import json
import hashlib
import os
from pathlib import Path
import re
import subprocess
import threading
import tempfile
from runtime_paths import state_directory

ROOT = Path(__file__).resolve().parent
try:
    PROFILE = json.loads((ROOT/'packaging'/'argos'/'profile.json').read_text(encoding='utf-8'))
except (OSError,ValueError):
    PROFILE = {}  # An incomplete optional-runtime upgrade must not stop OWNER.
TIMEOUT = 30  # Bounded CPU work; only the translation-editor request gets a longer deadline.
_SLOT = threading.BoundedSemaphore(1)
TOKEN = re.compile(r'(MSKEEP[A-F0-9]{24}X\d+END)')


class ArgosError(Exception):
    pass


def home():
    selected = Path(os.environ.get('MATH_ARGOS_HOME') or state_directory()/'translation').expanduser()
    if not selected.is_absolute():
        raise ArgosError('Argos storage must use an absolute path.')
    path = selected.resolve()
    if path == ROOT or ROOT in path.parents:
        raise ArgosError('Argos storage must be outside the application folder.')
    return path


def python_path():
    return home()/'runtime'/('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def ready():
    try:
        base = home()
        receipt = base/'installation.json'
        if not python_path().is_file() or not receipt.is_file() or receipt.stat().st_size > 16384 or (base/'.setup.lock').exists():
            return False
        info = json.loads(receipt.read_text(encoding='utf-8'))
        if info.get('schema') != 2 or info.get('profile') != PROFILE['id'] or info.get('argos') != '1.11.0' or not info.get('verified'):
            return False
        for pair in ('en_zh', 'zh_en'):
            item = info['models'][pair]
            folder = base/'packages'/item['folder']
            if folder.parent != base/'packages' or not (folder/'metadata.json').is_file() or not (folder/'model'/'model.bin').is_file():
                return False
            spec=PROFILE['sentence_models'][pair];sentence=folder/'minisbd'/spec['filename']
            if not sentence.is_file() or sentence.stat().st_size>32*1024**2:
                return False
            with sentence.open('rb') as source:
                if hashlib.file_digest(source,'sha256').hexdigest()!=spec['sha256']:return False
        return True
    except (ArgosError, OSError, ValueError, KeyError, TypeError):
        return False


def environment(base):
    # Inference receives no API keys, TURN secrets, account paths or provider credentials.
    allowed = ('PATH','SYSTEMROOT','WINDIR','TEMP','TMP','COMSPEC','PATHEXT','LD_LIBRARY_PATH')
    env = {k: os.environ[k] for k in allowed if k in os.environ}
    env.update(USERPROFILE=str(base), LOCALAPPDATA=str(base/'cache'), APPDATA=str(base/'config'),
               STANZA_RESOURCES_DIR=str(base/'data'/'stanza'), PYTHONUTF8='1', PYTHONIOENCODING='utf-8', ARGOS_PACKAGES_DIR=str(base/'packages'),
               XDG_DATA_HOME=str(base/'data'), XDG_CONFIG_HOME=str(base/'config'), XDG_CACHE_HOME=str(base/'cache'),
               ARGOS_MODEL_PROVIDER='OPENNMT', ARGOS_DEVICE_TYPE='cpu', ARGOS_CHUNK_TYPE='MINISBD',
               ARGOS_INTER_THREADS='1', ARGOS_INTRA_THREADS='1', ARGOS_COMPUTE_TYPE='int8',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TORCH_HOME=str(base/'cache'/'torch'), HF_HOME=str(base/'cache'/'huggingface'))
    return env


def worker_json(data):
    # Protocol output is UTF-8 only. Never repair corrupt JSON with replacement.
    return json.loads(data.decode('utf-8'))


def run_worker(payload,*,base,packages=None,diagnostics=True):
    # Native runtimes can cache stdout before main() redirects it. Response data
    # therefore has its own private, parent-created location, never a log pipe.
    with tempfile.TemporaryDirectory(prefix='response-',dir=base) as directory:
        path=Path(directory)/'result.json';env=environment(base)
        env['MATH_ARGOS_RESULT_FILE']=str(path)
        if packages is not None:env['ARGOS_PACKAGES_DIR']=str(packages)
        options={}
        if os.name=='nt':options['creationflags']=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS
        result=subprocess.run([str(python_path()),'-I','-u',str(ROOT/'argos_worker.py')],
            input=json.dumps(payload,ensure_ascii=False).encode('utf-8'),stdout=subprocess.PIPE if diagnostics else subprocess.DEVNULL,
            stderr=subprocess.PIPE if diagnostics else subprocess.DEVNULL,timeout=TIMEOUT,cwd=base,env=env,**options)
        result.response_present=path.is_file()
        result.response=b''
        if result.response_present:
            with path.open('rb') as stream:result.response=stream.read(150001)
        return result


def _json_shape(data):
    # Classification only: an embedded object never makes corrupt protocol valid.
    info={'json_parse':'empty','json_object':False,'pieces_exists':False,
          'pieces_type':None,'pieces_count':None,'piece_types':{},'non_json_output':False}
    if not data:return info
    if len(data)>150000:
        info.update(json_parse='oversized',non_json_output=True);return info
    invalid_utf8=False
    try:text=data.decode('utf-8')
    except UnicodeDecodeError:
        info.update(json_parse='invalid_utf8',non_json_output=True)
        invalid_utf8=True;text=data.decode('utf-8',errors='replace')
    try:
        obj=json.loads(text)
        if not invalid_utf8:info['json_parse']='valid'
    except ValueError:
        if not invalid_utf8:info['json_parse']='invalid_json'
        info['non_json_output']=True;obj=None
        decoder=json.JSONDecoder()
        starts=(match.start() for match in re.finditer(r'\{',text))
        for _,start in zip(range(16),starts):
            try:candidate,_=decoder.raw_decode(text,start)
            except ValueError:continue
            if isinstance(candidate,dict):obj=candidate;break
    if isinstance(obj,dict):
        info['json_object']=True;info['pieces_exists']='pieces' in obj
        if 'pieces' in obj:
            pieces=obj['pieces'];info['pieces_type']=type(pieces).__name__
            if isinstance(pieces,list):
                info['pieces_count']=len(pieces)
                for item in pieces:
                    name=type(item).__name__;info['piece_types'][name]=info['piece_types'].get(name,0)+1
    return info


def worker_response_info(result):
    stdout=result.stdout or b''
    stdout_shape=_json_shape(stdout)
    return {'exit_code':result.returncode,'transport':'private_file','response_present':result.response_present,
            'response':_json_shape(result.response),'stdout':stdout_shape,
            'unexpected_stdout':bool(stdout.strip()),'unexpected_non_json_stdout':stdout_shape['non_json_output']}


def worker_diagnostic(data):
    # Native Windows diagnostics may use an ANSI codepage. Decode lossily only
    # on this non-protocol channel, then retain the sanitized ASCII record only.
    notes=[]
    for line in (data or b'').decode('utf-8',errors='replace').splitlines():
        if line.startswith('ARGOS_DIAGNOSTIC '):
            value=line.removeprefix('ARGOS_DIAGNOSTIC ')
            if re.fullmatch(r'[A-Za-z0-9_.:=; -]{1,1500}',value):notes.append(value)
    return notes[-1] if notes else 'No safe exception record; confirm argos_worker.py is updated.'


def translate(text, target):
    if target not in ('en', 'zh') or not isinstance(text, str) or len(text) > 20000:
        raise ArgosError('Invalid offline translation request.')
    if not ready():
        raise ArgosError('Offline translation models are unavailable. Run OWNER offline translation setup.')
    if not _SLOT.acquire(blocking=False):
        raise ArgosError('Offline translation is busy. Try again shortly.')
    try:
        # Tokens/names/math never pass through the model. They are rejoined verbatim.
        pieces = TOKEN.split(text)
        payload = {'target': target, 'pieces': pieces[::2]}
        try:
            result = run_worker(payload,base=home(),diagnostics=False)
        except subprocess.TimeoutExpired:
            raise ArgosError('Offline translation timed out. Original content is unchanged.') from None
        except OSError:
            raise ArgosError('Offline translation could not start. Run OWNER offline translation setup.') from None
        if result.returncode or not result.response_present or len(result.response) > 150000:
            raise ArgosError('Offline translation failed. Original content is unchanged.')
        try:
            translated = worker_json(result.response)['pieces']
            if not isinstance(translated,list) or len(translated) != len(pieces[::2]) or any(not isinstance(x,str) or len(x)>20000 for x in translated):
                raise ValueError()
        except (ValueError, KeyError, TypeError):
            raise ArgosError('Offline translation failed. Original content is unchanged.') from None
        pieces[::2] = translated
        output = ''.join(pieces)
        if len(output) > 20000:
            raise ArgosError('Offline translation result is too large.')
        return output
    finally:
        _SLOT.release()
